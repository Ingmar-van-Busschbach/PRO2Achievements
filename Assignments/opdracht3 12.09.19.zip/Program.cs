﻿using System;

namespace opdracht2
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Clear();

            Console.WriteLine("Insert your name");

            string name = Console.ReadLine();

            Console.WriteLine("Hello", name);

            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("###########################");
            Console.WriteLine("#####      Round 1     ####");
            Console.WriteLine("###########################");

            int dwStartTime = System.Environment.TickCount;

            while (true)

            {

                if (System.Environment.TickCount - dwStartTime > 500) break; //1000 milliseconds 

            }

            Console.Clear();

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("###########################");
            Console.WriteLine("#####      Round 1     ####");
            Console.WriteLine("###########################");

            while (true)

            {

                if (System.Environment.TickCount - dwStartTime > 1000) break; //1000 milliseconds 

            }

            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("###########################");
            Console.WriteLine("#####  BOT vs {0}  ###", name);
            Console.WriteLine("###########################");

            while (true)

            {

                if (System.Environment.TickCount - dwStartTime > 1500) break; //1000 milliseconds 

            }

            Console.Clear();

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("###########################");
            Console.WriteLine("#####  BOT vs {0}  ###", name);
            Console.WriteLine("###########################");

            while (true)

            {

                if (System.Environment.TickCount - dwStartTime > 2500) break; //1000 milliseconds 

            }

            Console.Clear();

            Console.WriteLine("###########################");
            Console.WriteLine("#####      FIGHT!!     ####");
            Console.WriteLine("###########################");

            Console.ReadLine();

        }
    }
}
