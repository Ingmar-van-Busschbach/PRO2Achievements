namespace quizEngine{
    class Answer{
        private string answer;
        public Answer(string answer){
            this.answer = answer;
        }
        public string GetString(){
            return this.answer;
        }
    }

    class Answer2{
        private string answer2;
        public Answer2(string answer2)
        {
            this.answer2 = answer2;
        }
        public string GetString()
        {
            return this.answer2;
        }
    }

    class Answer3
    {
        private string answer3;
        public Answer3(string answer3)
        {
            this.answer3 = answer3;
        }
        public string GetString()
        {
            return this.answer3;
        }
    }
}